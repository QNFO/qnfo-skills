﻿# Provenance Manifest — Harmonic Resonance Computing v2.0.0

## Chain of Custody
1. Research conducted: 2026-07-14
2. Agent: DeepChat Agent (deepseek-v4-pro)
3. Built on: HRC v1.1.1 (DOI 10.5281/zenodo.16566060) + Mass-Frequency Identity v3.2.0 (DOI 10.5281/zenodo.21360549)

## Bundle Contents
| File | Description |
|:-----|:------------|
| conversation.md | Full LLM-agent dialogue |
| session-metadata.json | Agent, model, git state |
| project-files/ | Workspace snapshot |
| git-state.txt | Git log and status |
| PROVENANCE.md | This manifest |
| README.md | Entry point |

## Verification
1. Read conversation.md for research dialogue
2. Examine project-files/ for working code
3. Cross-reference claims against conversation and code
4. Check git-state.txt for commit state
