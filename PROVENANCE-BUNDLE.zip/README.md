﻿# Harmonic Resonance Computing — v2.0.0
**DOI:** PENDING | **Author:** Rowan Brad Quni | **Date:** 2026-07-14
**License:** CC-BY-4.0

## What This Is
Harmonic Resonance Computing v2.0.0 — major update integrating the Mass-Frequency Identity (m=ω), BPP/BQP watershed, interpretation-neutral ontology, and concrete engineering pathways.

## Quick Start
Open HRC_v2.0.0_draft.md (canonical Markdown) or HRC_v2.0.0.pdf (rendered).

## Provenance
Conducted by DeepChat Agent. Full conversation history in PROVENANCE-BUNDLE.zip.
